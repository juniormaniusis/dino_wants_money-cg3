You can easily change texture color in Photoshop to any color you want

Thanks for buying my model!!!

-Lyrog :)